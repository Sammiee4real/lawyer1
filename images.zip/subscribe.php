<footer class="footer">
		<div class="container"> 
			<div class="row"> 
				<div class="col-md-12"> 
					<div class="subscribe-text">
						<h3>Subscribe for Newsletter</h3>
						<p>Lorem ipsum madolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor coli incididunt ut labore Lorem ipsum madolor sit amet, consectetur adipisicing incididunt.</p>
					</div>
					
					<div class="subscribe-form">
						<form>
							<input class="form-control" id="subscribe_email" name="email" placeholder="Email Address..." required="" type="email">
							<button type="submit" class="btn subscribe-btn"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
						</form>
					</div>
				</div>
			</div>
		</div>
    </footer>