 <div class="copyrights">
        <div class="container">
            <div class="footer-distributed">
                <div class="footer-left">                    
                    <p class="footer-company-name" style="color: white;">All Rights Reserved. &copy; 2018 <a href="#">Wunmi Law</a> Designed By 
					<a href="#">Konnectine Tech and Comms.</a></p>
                </div>
            </div>
        </div><!-- end container -->
    </div><!-- end copyrights -->
