  <header class="header header_style_01">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
				<a class="navbar-brand" href="#">WUNMI LAW</a><!-- <img src="images/logos/logo-app.png" alt="image"> -->
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarApp" aria-controls="navbarApp" aria-expanded="false" aria-label="Toggle navigation">
					<span></span>
					<span></span>
					<span></span>
				</button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarApp">
                    <ul class="navbar-nav">
                        <li><a class="nav-link active" href="#home">Home</a></li>
                        <li><a class="nav-link" href="#features">About Me</a></li>
                        <li><a class="nav-link" href="#clients">Portfolio</a></li>
                       <li><a class="nav-link" href="#pricing">Testimonials</a></li>
                       <li><a class="nav-link" href="#clients">Hire Me</a></li>
                       <li><a class="nav-link" href="#faqs">Contacts</a></li>
                       <!--  <li><a class="nav-link" href="#download">Download</a></li>
                        <li><a class="nav-link" href="#pricing">Pricing</a></li>
                        <li><a class="nav-link" href="#clients">Clients</a></li>
                        <li><a class="nav-link" href="#faqs">FAQs</a></li>
						<li><a class="nav-link" href="#contact">Contact</a></li> -->
                    </ul>
                </div>
            </div>
        </nav>
    </header>	